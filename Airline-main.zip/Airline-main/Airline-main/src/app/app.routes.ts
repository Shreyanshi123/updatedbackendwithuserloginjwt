import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { SearchComponent } from './components/search/search.component';
import { ScheduleComponent } from './components/schedule/schedule.component';
import { AddFlightComponent } from './components/add-flight/add-flight.component';
import { EditairlineComponent } from './components/editairline/editairline.component';
import { BookingComponent } from './components/booking/booking.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { authGuard } from './guards/auth.guard';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';

export const routes: Routes = [
{path:'',component:HomeComponent},
{path:'home',component:HomeComponent},
 {path:'search',component:SearchComponent},
 { path: 'home/booking', component: BookingComponent },
 {path:"dashboard/login",component:LoginComponent},
 {path:"dashboard/register",component:RegisterComponent},
 {path:'dashboard',component:DashboardComponent,canActivate:[authGuard],children:[
{path:'editFlight/:flightNumber',component:EditairlineComponent},
 {path:'addFlight',component:AddFlightComponent},
 { path: 'schedule', component: ScheduleComponent },
 ]},

// { path: 'home/booking/manage', component: ManageComponent },
];
