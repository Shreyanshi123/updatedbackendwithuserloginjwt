import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import {jwtDecode} from 'jwt-decode';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  
  private API_URL = 'https://localhost:7261/api';
  constructor(private http: HttpClient) { }

  signUp(user: any): Observable<any> {
    return this.http.post(`${this.API_URL}/Registration`, user);
  }

  signIn(user: any): Observable<any> {
    return this.http.post(`${this.API_URL}/Login/login`, user);
  }
  signOut() {
    localStorage.removeItem('token');
  }

  getToken(){
    return localStorage.getItem('token');
  }

  dataFromToken(){
    const token = this.getToken();
    if(token){
      var decodedToken = jwtDecode(token) as{
        "http://schemas.microsoft.com/ws/2008/06/identity/claims/role": string;};
        var userRole = decodedToken["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"];
        return userRole;
      }
      else{
        return "";
      }
      }
    }
 
