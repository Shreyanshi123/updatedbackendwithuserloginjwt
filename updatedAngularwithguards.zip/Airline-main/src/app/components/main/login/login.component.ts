import { Component, inject} from '@angular/core';
import { AuthService } from '../../../services/auth.service';
import { Router } from '@angular/router';
import { FormControl,FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  authService = inject(AuthService);
  constructor(private router: Router) {};

   formData:FormGroup= new FormGroup({
  emailId:new FormControl('',Validators.required),
    password:new FormControl('',[Validators.required]),
    
})

 loginControl(): void {
  // Add logic to validate user credentials here
  let myFormData = this.formData.value;
    console.log(this.formData.value);
    this.authService.signIn(myFormData)
      .subscribe({
        next:(data:any)=>{
          var token = data.token;
          // localstorage save
          localStorage.setItem("token",token);
          // var decodedToken = jwtDecode(token) as { 
          //   "http://schemas.microsoft.com/ws/2008/06/identity/claims/role": string;};
          // var userRole = decodedToken["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"];
          // console.log(userRole);
          //token generated
          // claimtype role 
          console.log(token)
          if(this.authService.dataFromToken()=="user"){
            this.router.navigateByUrl('/home');
          }
          if(this.authService.dataFromToken()=="Admin"){
            this.router.navigateByUrl('/dashboard')
          }
          // else {
          //   console.error('Login failed:', data.msg);
          // }
        },
        error:(err:any)=>{
          console.log(err);
        }
      })
  // Navigate to the dashboard
  // this.router.navigate(['/dashboard/dashboard']);
}


}
